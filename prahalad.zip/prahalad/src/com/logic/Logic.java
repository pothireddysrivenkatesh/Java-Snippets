package com.logic;

public class Logic {
	
	public static long fact(int fact) {
		
        long factorial = 1;
        for(int i = 1; i <= fact; ++i)
        {
            // factorial = factorial * i;
            factorial *= i;
        }
        return factorial;
	}
	
	public static boolean palindrome(int no) {
		int r,sum=0,temp;    
		  
		  temp=no;    
		  while(no>0){    
		   r=no%10;  //getting remainder  
		   sum=(sum*10)+r;    
		   no=no/10;    
		  }    
		  if(temp==sum)    
		   return true; 
		  else    
		   return false;    
		}  
	
	public static boolean prime(int no) {
        boolean flag = false;
        for(int i = 2; i <= no/2; ++i)
        {
            if(no % i == 0)
            {
                flag = true;
                break;
            }
        }

        if (!flag)
            return true;
        else
            return false;
	}

}
