package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.logic.Logic;

/**
 * Servlet implementation class Converter
 */
@WebServlet("/Converter")
public class Converter extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Converter() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String conversion_type = request.getParameter("converter_type");
		int value = Integer.parseInt(request.getParameter("value"));
		boolean resultb;
		long resultl;
		String message; 
		if(conversion_type.equals("Palindrome")) {
			resultb=Logic.palindrome(value);
			if(resultb) {
				message="Is a Palindrome";
			}
			else {
				message="Is not a Palindrome";
			}
			request.setAttribute("msg",message);
			request.getRequestDispatcher("result.jsp").forward(request, response);
		}
		if(conversion_type.equals("Prime Number")) {
			resultb=Logic.prime(value);
			if(resultb) {
				message="Is a Prime";
			}
			else {
				message="Is not a Prime";
			}
			request.setAttribute("msg",message);
			request.getRequestDispatcher("result.jsp").forward(request, response);
		}
		else {
			resultl = Logic.fact(value);
			message="The factorial is";
			request.setAttribute("result",resultl);
			request.setAttribute("msg",message);
			request.getRequestDispatcher("resultl.jsp").forward(request, response);
		}
	
	}


}
