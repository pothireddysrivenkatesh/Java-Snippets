/**
 * 
 */
var emp = [{ "name": "abc", "age": 12, "add": "hyd", "id": 1 }, { "name": "bcd", "age": 15, "add": "mtm", "id": 2 }, { "name": "edf", "age": 25, "add": "vjw", "id": 3} ];
var tab = document.getElementById("table");
var text = "";
for (let i = 0; i < emp.length; i++) {
    text = text + "<tr>";
    text = text + "<td>";
    text = text + (emp[i].id);
    text = text + "</td>";
    text = text + "<td>";
    text = text + (emp[i].name);
    text = text + "</td>";
    text = text + "<td>";
    text = text + (emp[i].age);
    text = text + "</td>";
    text = text + "<td>";
    text = text + (emp[i].add);
    text = text + "</td>";
    text = text + "<td>";
    text = text + '<a href="details.html" onclick="funs[i]">CLick to know more</a>';
    text = text + "</td>";
    text = text + "</tr>";
}

tab.innerHTML = text;
var funs = [function fun0() { var }];
