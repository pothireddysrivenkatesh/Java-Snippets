/**
 * 
 */
var emp = [{ "name": "abc", "age": 12, "add": "hyd", "id": 1 }, { "name": "bcd", "age": 15, "add": "mtm", "id": 2 }, { "name": "edf", "age": 25, "add": "vjw", "id": 3} ];
var tab = document.getElementById("table");
var text = "";
for (var i = 0; i < emp.length; i++) {
    text = text + "<tr>";
    text = text + "<td>";
    text = text + (emp[i].id);
    text = text + "</td>";
    text = text + "<td>";
    text = text + (emp[i].name);
    text = text + "</td>";
    text = text + "<td>";
    text = text + (emp[i].age);
    text = text + "</td>";
    text = text + "<td>";
    text = text + (emp[i].add);
    text = text + "</td>";
    text = text + "<td>";
    text = text + '<a href="" onclick="return fun('+i+')">Know more</a>';
    text = text + "</td>";
    text = text + "</tr>";
}

tab.innerHTML = text;

var details = document.getElementById("details");
var para = "";
//console.log(document.getElementById("table").getAttribute('onclick'));
function fun(no){
	var det = [emp[no].id,emp[no].name,emp[no].age,emp[no].add];
	para = "Name of Employee is :"+det[1]+"<br>";
	para = para + "ID of the Employee is :"+det[0]+"<br>";
	para = para + "Age of the Employee is :"+det[2]+"<br>";
	para = para + "Location :" +det[3]+"<br>";
	console.log(para);
	details.innerHTML = para;
	return false;
}

