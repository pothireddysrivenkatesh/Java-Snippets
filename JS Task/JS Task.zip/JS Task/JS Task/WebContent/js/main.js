function validate(){
	var usr = document.forms["form"]["usr"].value;
	var pass = document.forms["form"]["pass"].value;
	
	
	if(usr!="" && pass!=""){
		var usrRegex = /\S+@\S+\.\S+/;
		var u_bool = usrRegex.test(usr);
		var passRegex =  /^[a-zA-Z0-9!@#$%^&*]{8,16}$/;
		var p_bool = passRegex.test(pass);
		
		if(!u_bool){
			alert("E-mail Must Contain a @ and '.' domain");
			return false;
		}
		
		if(!p_bool){
			alert("Password must contain a Uppercase, Lowercase, Numerical and a Special Character.");
			return false;
		}
		
		if(u_bool && p_bool){
			return true;
		}
		
	}
	else{
		alert("Username or password cant be empty");
		return false;
	}
	
}