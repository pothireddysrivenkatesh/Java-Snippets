package com.CreditCard;


public class CardInfo {

	private String CardNum="";
	private String BankName="";
	private String CardType="";
	private boolean Valid;
	
	public String getCardNum() {
		return CardNum;
	}
	
	public void setCardNum(String cardNum) {
		CardNum = cardNum;
	}
	
	public String getBankName() {
		return BankName;
	}
	
	public void setBankName(String bankName) {
		BankName = bankName;
	}
	
	public String getCardType() {
		return CardType;
	}
	
	public void setCardType(String cardType) {
		CardType = cardType;
	}
	
	public boolean isValid() {
		return Valid;
	}
	
	public void setValid(boolean valid) {
		Valid = valid;
	}
	
	

}
