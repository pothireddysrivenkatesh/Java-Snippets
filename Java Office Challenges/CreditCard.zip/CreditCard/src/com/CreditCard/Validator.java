package com.CreditCard;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Validator extends HttpServlet{
	/**
	 * 
	 */
	Validator(){
		System.out.println("Constructor");
		
	}
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String number = req.getParameter("number");
		
		
		Validator va = new Validator();
		
		
		CardInfo card;
		Logic lo = new Logic();
		card = lo.Validation(number);
		PrintWriter wrt = resp.getWriter();
		wrt.println("<html><body><h3>The entered card number is  "+number+"</h3></body></html>");
		wrt.println("<html><body><h3>The Card belongs to "+card.getBankName()+" Bank</h3></body></html>");
		wrt.println("<html><body><h3>The Card is a "+card.getBankName()+" Cardk</h3></body></html>");
		wrt.println("<html><body><h3>The Card number is "+card.isValid()+"</h3></body></html>");
		wrt.println("<html><body><h3>"+va+"</h3></body></html>");
	}

	

}
