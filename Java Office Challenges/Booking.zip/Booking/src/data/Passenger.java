package data;

public class Passenger {
	public String[] pass=new String[5];
	public String[] ages=new String[5];
	public String[] gens=new String[5];
	public String jdate;
	public String tname;
	public String nopass;
	public String coach;
	public int pnr;
	public int price;
	
}
