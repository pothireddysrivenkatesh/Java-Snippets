package control;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import data.Passenger;
import data.TrainsList;

public class credit implements Controller {
	
	static public Passenger passen = new Passenger();
	@Override
	public ModelAndView handleRequest(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		String passno = req.getParameter("passno");
		int no = Integer.parseInt(passno);
		String date = req.getParameter("date");
		passen.jdate = date;
		passen.nopass = passno;
		
			
		
		Map m = new HashMap<String, String>();
		
	
		if(no==1) {
			passen.pass[0] = req.getParameter("p1");
			passen.ages[0] = req.getParameter("age1");
			passen.gens[0] = req.getParameter("gen1");
			m.put("p1",passen.pass[0]);
			m.put("a1",passen.ages[0]);
			m.put("g1",passen.gens[0]);

		}
		if(no==2) {
			passen.pass[0] = req.getParameter("p1");
			passen.ages[0] = req.getParameter("age1");
			passen.gens[0] = req.getParameter("gen1");
			m.put("p1",passen.pass[0]);
			m.put("a1",passen.ages[0]);
			m.put("g1",passen.gens[0]);
			passen.pass[1] = req.getParameter("p2");
			passen.ages[1] = req.getParameter("age2");
			passen.gens[1] = req.getParameter("gen2");
			m.put("p2",passen.pass[1]);
			m.put("a2",passen.ages[1]);
			m.put("g2",passen.gens[1]);
		}
		
		if(no==3) {
			passen.pass[0] = req.getParameter("p1");
			passen.ages[0] = req.getParameter("age1");
			passen.gens[0] = req.getParameter("gen1");
			m.put("p1",passen.pass[0]);
			m.put("a1",passen.ages[0]);
			m.put("g1",passen.gens[0]);
			passen.pass[1] = req.getParameter("p2");
			passen.ages[1] = req.getParameter("age2");
			passen.gens[1] = req.getParameter("gen2");
			m.put("p2",passen.pass[1]);
			m.put("a2",passen.ages[1]);
			m.put("g2",passen.gens[1]);
			passen.pass[2] = req.getParameter("p3");
			passen.ages[2] = req.getParameter("age3");
			passen.gens[2] = req.getParameter("gen3");
			m.put("p3",passen.pass[2]);
			m.put("a3",passen.ages[2]);
			m.put("g3",passen.gens[2]);
		}
		
		if(no==4) {
			passen.pass[0] = req.getParameter("p1");
			passen.ages[0] = req.getParameter("age1");
			passen.gens[0] = req.getParameter("gen1");
			m.put("p1",passen.pass[0]);
			m.put("a1",passen.ages[0]);
			m.put("g1",passen.gens[0]);
			passen.pass[1] = req.getParameter("p2");
			passen.ages[1] = req.getParameter("age2");
			passen.gens[1] = req.getParameter("gen2");
			m.put("p2",passen.pass[1]);
			m.put("a2",passen.ages[1]);
			m.put("g2",passen.gens[1]);
			passen.pass[2] = req.getParameter("p3");
			passen.ages[2] = req.getParameter("age3");
			passen.gens[2] = req.getParameter("gen3");
			m.put("p3",passen.pass[2]);
			m.put("a3",passen.ages[2]);
			m.put("g3",passen.gens[2]);
			passen.pass[3] = req.getParameter("p4");
			passen.ages[3] = req.getParameter("age4");
			passen.gens[3] = req.getParameter("gen4");
			m.put("p4",passen.pass[3]);
			m.put("a4",passen.ages[3]);
			m.put("g4",passen.gens[3]);
		}
		
		if(no==5) {
			passen.pass[0] = req.getParameter("p1");
			passen.ages[0] = req.getParameter("age1");
			passen.gens[0] = req.getParameter("gen1");
			m.put("p1",passen.pass[0]);
			m.put("a1",passen.ages[0]);
			m.put("g1",passen.gens[0]);
			passen.pass[1] = req.getParameter("p2");
			passen.ages[1] = req.getParameter("age2");
			passen.gens[1] = req.getParameter("gen2");
			m.put("p2",passen.pass[1]);
			m.put("a2",passen.ages[1]);
			m.put("g2",passen.gens[1]);
			passen.pass[2] = req.getParameter("p3");
			passen.ages[2] = req.getParameter("age3");
			passen.gens[2] = req.getParameter("gen3");
			m.put("p3",passen.pass[2]);
			m.put("a3",passen.ages[2]);
			m.put("g3",passen.gens[2]);
			passen.pass[3] = req.getParameter("p4");
			passen.ages[3] = req.getParameter("age4");
			passen.gens[3] = req.getParameter("gen4");
			m.put("p4",passen.pass[3]);
			m.put("a4",passen.ages[3]);
			m.put("g4",passen.gens[3]);
			passen.pass[4] = req.getParameter("p5");
			passen.ages[4] = req.getParameter("age5");
			passen.gens[4] = req.getParameter("gen5");
			m.put("p5",passen.pass[4]);
			m.put("a5",passen.ages[4]);
			m.put("g5",passen.gens[4]);
		}
		if(no==6) {
			passen.pass[0] = req.getParameter("p1");
			passen.ages[0] = req.getParameter("age1");
			passen.gens[0] = req.getParameter("gen1");
			m.put("p1",passen.pass[0]);
			m.put("a1",passen.ages[0]);
			m.put("g1",passen.gens[0]);
			passen.pass[1] = req.getParameter("p2");
			passen.ages[1] = req.getParameter("age2");
			passen.gens[1] = req.getParameter("gen2");
			m.put("p2",passen.pass[1]);
			m.put("a2",passen.ages[1]);
			m.put("g2",passen.gens[1]);
			passen.pass[2] = req.getParameter("p3");
			passen.ages[2] = req.getParameter("age3");
			passen.gens[2] = req.getParameter("gen3");
			m.put("p3",passen.pass[2]);
			m.put("a3",passen.ages[2]);
			m.put("g3",passen.gens[2]);
			passen.pass[3] = req.getParameter("p4");
			passen.ages[3] = req.getParameter("age4");
			passen.gens[3] = req.getParameter("gen4");
			m.put("p4",passen.pass[3]);
			m.put("a4",passen.ages[3]);
			m.put("g4",passen.gens[3]);
			passen.pass[4] = req.getParameter("p5");
			passen.ages[4] = req.getParameter("age5");
			passen.gens[4] = req.getParameter("gen5");
			m.put("p5",passen.pass[4]);
			m.put("a5",passen.ages[4]);
			m.put("g5",passen.gens[4]);
			passen.pass[5] = req.getParameter("p6");
			passen.ages[5] = req.getParameter("age6");
			passen.gens[5] = req.getParameter("gen6");
			m.put("p6",passen.pass[5]);
			m.put("a6",passen.ages[5]);
			m.put("g6",passen.gens[5]);
		}
		
		String tname = req.getParameter("tnum");
		ApplicationContext ap = new ClassPathXmlApplicationContext("data/trains.xml");
		TrainsList tl = (TrainsList) ap.getBean(tname);
		
		int totalprice = no * tl.getPrice();
		
		passen.tname = tl.getTrainName();
		passen.price = totalprice;
		
		m.put("tnum",tl.getTrainNumber());
		m.put("tname", tl.getTrainName());
		m.put("seats",tl.getSeats());
		m.put("src",tl.getSource());
		m.put("des",tl.getDestination());
		m.put("date",date);
		m.put("tickprice",totalprice);
		m.put("passno",no);
		
		
		ModelAndView mav = new ModelAndView("pay",m);
		
		
		return mav;
		
		
	}

}
