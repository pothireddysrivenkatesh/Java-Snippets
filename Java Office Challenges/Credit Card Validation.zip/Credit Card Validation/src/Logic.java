
public class Logic {
	public CardInfo Validation(String CardNum) {
		CardInfo cd = new CardInfo();
		cd.setCardNum(CardNum);
		String num = cd.getCardNum();
		char[] arrno = num.toCharArray();
		int [] arr= new int[16];
		//COnversion to Integers
		for (int i = 0;i<arr.length;i++) {
			arr[i]=arrno[i]-48;
		}
			
		//Cartype Validation
		if(arr[0]==4)
			cd.setCardType("Visa");
		else if(arr[0]==5)
			cd.setCardType("Rupay");
		else if(arr[0]==6)
			cd.setCardType("Master");
		else if(arr[0]==7)
			cd.setCardType("Citi");
		else {
			cd.setValid(false);
			return cd;
		}
		
		//Bank Validation
		int BankNum=0;
		for(int i = 0;i<4;i++) {
			BankNum=BankNum+arr[i];
		}
		if(BankNum<=5)
			cd.setBankName("SBI");
		else if(BankNum>5 && BankNum <= 10)
			cd.setBankName("City");
		else if(BankNum>10 && BankNum <= 15)
			cd.setBankName("ICICI");
		else if(BankNum>15 && BankNum <= 20)
			cd.setBankName("Kotak Mahindra");
		else if(BankNum > 20 && BankNum <= 25)
			cd.setBankName("HDFC");
		else if(BankNum > 25 && BankNum <= 30)
			cd.setBankName("Andhra Bank");
		else if(BankNum > 30 && BankNum <=35)
			cd.setBankName("SBH");
		else {
			cd.setValid(false);
			return cd;
		}
		
		//Card Number Validation
		int valid = 0;
		for(int i = 0; i<num.length();i=i+2) {
			int down = 0;
			int first = 0;
			int last = 0;
			down = arr[i];
			down = down * 2;
			last=down%10;
			first=down/10;
			valid = valid + first + last;
		}
		for(int i = 1;i<num.length();i=i+2)
			valid = valid + arr[i];
		if(valid%10==0)
			cd.setValid(true);
		else cd.setValid(false);
		
		return cd;
	}
}
