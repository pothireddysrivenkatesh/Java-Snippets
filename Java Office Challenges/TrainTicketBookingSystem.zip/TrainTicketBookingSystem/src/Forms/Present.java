package Forms;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;


public class Present {

	private int PNR;
	private int Tno;
	private String TrainName;
	private long phnno;
	private int seats;
	private String Source;
	private String Destination;
	@DateTimeFormat(pattern = "dd/mm/yyyy")
	protected Date journeyDate;
	private String CClass;
	private String Pnames[];
	private int ages[];
	private char[] gender;
	
	public String[] getPnames() {
		return Pnames;
	}
	public void setPnames(String[] pnames) {
		Pnames = pnames;
	}
	public int[] getAges() {
		return ages;
	}
	public void setAges(int[] ages) {
		this.ages = ages;
	}
	public char[] getGender() {
		return gender;
	}
	public void setGender(char[] gender) {
		this.gender = gender;
	}
	public String getSource() {
		return Source;
	}
	public int getPNR() {
		return PNR;
	}
	public void setPNR(int pNR) {
		PNR = pNR;
	}
	public int getTno() {
		return Tno;
	}
	public void setTno(int tno) {
		Tno = tno;
	}
	public String getTrainName() {
		return TrainName;
	}
	public void setTrainName(String trainName) {
		TrainName = trainName;
	}
	public long getPhnno() {
		return phnno;
	}
	public void setPhnno(long phnno) {
		this.phnno = phnno;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	public void setSource(String source) {
		Source = source;
	}
	public String getDestination() {
		return Destination;
	}
	public void setDestination(String destination) {
		Destination = destination;
	}
	public Date getJourneyDate() {
		return journeyDate;
	}
	public void setJourneyDate(Date journeyDate) {
		this.journeyDate = journeyDate;
	}
	public String getCClass() {
		return CClass;
	}
	public void setCClass(String cClass) {
		CClass = cClass;
	}
	
}
