package Controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TrainControllers {
	
	@RequestMapping("/search")
	public String searching() {
		return "search";
	}

}
