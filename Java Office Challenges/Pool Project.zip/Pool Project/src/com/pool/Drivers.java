package com.pool;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Drivers")
public class Drivers extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
    	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String chlorinei = request.getParameter("chlorine");
		String phi = request.getParameter("ph");
		String cyacidi = request.getParameter("cyacid");
		
		float chlorine = Float.valueOf(chlorinei);
		float ph = Float.valueOf(phi);
		float cyacid = Float.valueOf(cyacidi);
				
		Parameters para;
		Reaction re = new Reaction();
		para = re.react(chlorine,ph,cyacid);
		
		PrintWriter wrt = response.getWriter();
		wrt.println("<html><body><h3>The number of cups of Cholrinator required to add is  "+para.getChlorinator()+"</h3></body></html>");
		wrt.println("<html><body><h3>The number cups of pHdown required are "+para.getPhdown()+"</h3></body></html>");
		wrt.println("<html><body><h3>The number cups of pHup required are "+para.getPhup()+"</h3></body></html>");
		
	}

	

}
