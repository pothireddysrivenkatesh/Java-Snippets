package com.pool;

public class Parameters {
	
	private int water;
	private float chlorine;
	private float ph;
	private float cyacid;
	
	private float chlorinator;
	private float phup;
	private float phdown;
	
	
	public float getChlorinator() {
		return chlorinator;
	}
	public void setChlorinator(float chlorinator) {
		this.chlorinator = chlorinator;
	}
	public float getPhup() {
		return phup;
	}
	public void setPhup(float phup) {
		this.phup = phup;
	}
	public float getPhdown() {
		return phdown;
	}
	public void setPhdown(float phdown) {
		this.phdown = phdown;
	}
	public int getWater() {
		return water;
	}
	public void setWater(int water) {
		this.water = water;
	}
	public float getChlorine() {
		return chlorine;
	}
	public void setChlorine(float chlorine) {
		this.chlorine = chlorine;
	}
	public float getPh() {
		return ph;
	}
	public void setPh(float ph) {
		this.ph = ph;
	}
	public float getCyacid() {
		return cyacid;
	}
	public void setCyacid(float cyacid) {
		this.cyacid = cyacid;
	}
	

}
