package com.pool;

public class Reaction {
	public Parameters react( float chlorine, float ph, float cyacid) {
		Parameters p = new Parameters();
		
		p.setChlorine(chlorine);
		p.setPh(ph);
		p.setCyacid(cyacid);
		
		
		
		if(ph>7.2 && ph<7.8) {
			p.setPhup(0.0f);
			p.setPhdown(0.0f);
		}
		else if(ph<7.2) {
		float temp = 0;
		temp=7.2f-ph;
		temp*=40;
		p.setPhup(temp);
		}
		else  {
			float temp = 0;
			temp=ph-7.2f;
			temp*=40;
			p.setPhdown(temp);
			}
		
		
		
		if(chlorine>3.0f) {
			p.setChlorinator(0);
		}
		else if(chlorine<1.0f) {
			float temp = 1-chlorine;
			temp*=40;
			p.setChlorinator(temp);
		}
		else {
			if(cyacid>100) {
				float temp = 3.0f-chlorine;
				temp*=40;
				float x =p.getChlorinator();
				p.setChlorinator(x+temp);
				p.setCyacid(cyacid - (temp)*5);
			}
		}
		
		
		
		return p;
	}

}
