package control;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import data.TrainsList;

public class ticket implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		Random rand = new Random();

		int  pnr = rand.nextInt(50) + 1 * 1500;
		
		String tnum =  req.getParameter("tnum") ;
		String []p = new String[6];
		String []a = new String[6];
		String []g = new String[6];	
		String date = req.getParameter("date");
		String price = req.getParameter("price");
		
ApplicationContext ap = new ClassPathXmlApplicationContext("data/trains.xml");
		
		TrainsList tl = (TrainsList) ap.getBean(tnum);
		
		Map m = new HashMap<String, String>();
		m.put("tnum",tl.getTrainNumber());
		m.put("tname", tl.getTrainName());
		m.put("seats",tl.getSeats());
		m.put("src",tl.getSource());
		m.put("des",tl.getDestination());
		m.put("date",date);
		p[0] = req.getParameter("p1");
		a[0] = req.getParameter("age1");
		g[0] = req.getParameter("gen1");
		m.put("p1",p[0]);
		m.put("a1",a[0]);
		m.put("g1",g[0]);
		p[1] = req.getParameter("p2");
		a[1] = req.getParameter("age2");
		g[1] = req.getParameter("gen2");
		m.put("p2",p[1]);
		m.put("a2",a[1]);
		m.put("g2",g[1]);
		p[2] = req.getParameter("p3");
		a[2] = req.getParameter("age3");
		g[2] = req.getParameter("gen3");
		m.put("p3",p[2]);
		m.put("a3",a[2]);
		m.put("g3",g[2]);
		p[3] = req.getParameter("p4");
		a[3] = req.getParameter("age4");
		g[3] = req.getParameter("gen4");
		m.put("p4",p[3]);
		m.put("a4",a[3]);
		m.put("g4",g[3]);
		p[4] = req.getParameter("p5");
		a[4] = req.getParameter("age5");
		g[4] = req.getParameter("gen5");
		m.put("p5",p[4]);
		m.put("a5",a[4]);
		m.put("g5",g[4]);
		p[5] = req.getParameter("p6");
		a[5] = req.getParameter("age6");
		g[5] = req.getParameter("gen6");
		m.put("p6",p[5]);
		m.put("a6",a[5]);
		m.put("g6",g[5]);
		m.put("pnr",pnr);
		
		ModelAndView mav = new ModelAndView("printing", m);
		
		
		return mav;
	}

}
