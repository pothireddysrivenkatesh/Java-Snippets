package control;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import data.TrainsList;

public class bookcontrol implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest req, HttpServletResponse res) throws Exception {
	
		String tnums = req.getParameter("tselect");
		String date = req.getParameter("date");
		int tnum = Integer.parseInt(tnums);
		
		ApplicationContext ap = new ClassPathXmlApplicationContext("data/trains.xml");
		
		TrainsList tl = (TrainsList) ap.getBean(tnums);
		
		Map m = new HashMap<String, String>();
		
		m.put("tnum",tl.getTrainNumber());
		m.put("tname", tl.getTrainName());
		m.put("seats",tl.getSeats());
		m.put("src",tl.getSource());
		m.put("des",tl.getDestination());
		m.put("date",date);
		
		
		

		
		
		ModelAndView mav = new ModelAndView("passdet",m);
		
		
		
		
		return mav;
	}

}
