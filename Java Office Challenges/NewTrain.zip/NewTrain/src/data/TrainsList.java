package data;
import java.util.List;

public class TrainsList {
	
	private int TrainNumber;
	private String TrainName;
	private String Source;
	private String Destination;
	private List<String> CClass;
	private int seats;
	private int price;
	//private List<String> Halts;
	
	
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	public void setCClass(List<String> cClass) {
		CClass = cClass;
	}
	public int getTrainNumber() {
		return TrainNumber;
	}
	public void setTrainNumber(int trainNumber) {
		TrainNumber = trainNumber;
	}
	public String getTrainName() {
		return TrainName;
	}
	public void setTrainName(String trainName) {
		TrainName = trainName;
	}
	public String getSource() {
		return Source;
	}
	public void setSource(String source) {
		Source = source;
	}
	public String getDestination() {
		return Destination;
	}
	public void setDestination(String destination) {
		Destination = destination;
	}
	public List<String> getCClass() {
		return CClass;
	}
	public void setClass(List<String> class1) {
		CClass = class1;
	}
	

	

}