
public class Validator {
CardInfo card;
Logic lo = new Logic();
card = lo.Validation("1234567890123456");
System.out.println(card.getBankName());
System.out.println(card.getCardType());
System.out.println(card.isValid());
}
