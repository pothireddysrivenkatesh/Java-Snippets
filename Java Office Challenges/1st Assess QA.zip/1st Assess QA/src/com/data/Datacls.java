package com.data;

import java.util.LinkedHashSet;
import java.util.Set;

public class Datacls {
	static String indata;
	static Set<Character> Setarr = new LinkedHashSet<Character>();
	static String result;
	static public String getIndata() {
		return indata;
	}
	static public void setIndata(String indata) {
		Datacls.indata = indata;
	}
	static public Set<Character> getSetarr() {
		return Setarr;
	}
	static public void setSetarr(Set<Character> setarr) {
		Setarr = setarr;
	}
	static public String getResult() {
		return result;
	}
	static public void setResult(String result) {
		Datacls.result = result;
	}
	

}
