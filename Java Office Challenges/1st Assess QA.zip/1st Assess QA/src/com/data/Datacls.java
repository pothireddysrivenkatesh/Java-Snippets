package com.data;

import java.util.LinkedHashSet;
import java.util.Set;

public class Datacls {
	
	
	String indata;
	Set<Character> Setarr = new LinkedHashSet<Character>();
	String result;
	
	
	public String getIndata() {
		return indata;
	}
	public void setIndata(String indata) {
		this.indata = indata;
	}
	public Set<Character> getSetarr() {
		return Setarr;
	}
	public void setSetarr(Set<Character> setarr) {
		Setarr = setarr;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	

}
