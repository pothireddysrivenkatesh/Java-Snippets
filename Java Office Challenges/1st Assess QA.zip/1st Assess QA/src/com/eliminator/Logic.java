package com.eliminator;

import com.data.Datacls;

public class Logic {


	public  Datacls logic(Datacls dc) {

		
		char[] chararr = dc.getIndata().toCharArray();
		for (char c : chararr) {
			dc.getSetarr().add(c);
		}
		StringBuilder sbres = new StringBuilder();
		for (Character character : dc.getSetarr()) {
			sbres.append(character);
		}
		dc.setResult(sbres.toString());
		
		return dc;

	}
}