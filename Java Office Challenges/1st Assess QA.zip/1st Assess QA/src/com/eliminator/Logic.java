package com.eliminator;

import com.data.Datacls;

public class Logic {
	
	public static void logic() {
	char[] chararr = Datacls.getIndata().toCharArray();
	for (char c : chararr) {
	    Datacls.getSetarr().add(c);
	}
	StringBuilder sbres = new StringBuilder();
	for (Character character : Datacls.getSetarr()) {
	    sbres.append(character);
	}
	Datacls.setResult(sbres.toString());
	
}
}