package com.duplicate;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.data.Datacls;
import com.eliminator.Logic;

/**
 * Servlet implementation class DuplicateEliminator
 */
@WebServlet("/DuplicateEliminator")
public class DuplicateEliminator extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DuplicateEliminator() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Datacls dc = new Datacls();
		dc.setIndata(request.getParameter("str"));
		response.setContentType("text/html");
		Logic lg = new Logic();
		dc = lg.logic(dc);
		request.setAttribute("result", dc.getResult());
		request.setAttribute("input", dc.getIndata());
		request.getRequestDispatcher("Result.jsp").forward(request, response);
		
	}

}
