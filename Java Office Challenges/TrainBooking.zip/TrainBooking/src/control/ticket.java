package control;

import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import data.TrainsList;

public class ticket implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		Random rand = new Random();

		int  n = rand.nextInt(50) + 1 * 1500;
		
ApplicationContext ap = new ClassPathXmlApplicationContext("data/trains.xml");
		
		TrainsList tl = (TrainsList) ap.getBean(
		
		return null;
	}

}
