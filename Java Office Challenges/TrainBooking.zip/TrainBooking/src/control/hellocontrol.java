package control;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import data.TrainsList;


public class hellocontrol implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		String src = req.getParameter("src");
		String des = req.getParameter("des");
		String date = req.getParameter("date");
		ApplicationContext ap = new ClassPathXmlApplicationContext("data/trains.xml");
		TrainsList tl = (TrainsList) ap.getBean("12345");
		
		String tsrc = tl.getSource();
		String tdes = tl.getDestination();
		int tnum;
		
		Map m = new HashMap<String, String>();
		
		if((src.equals(tsrc)) && (des.equals(tdes))) {
			tnum=tl.getTrainNumber();
			m.put("tnum",tnum);
			m.put("tname", tl.getTrainName());
			m.put("seats",tl.getSeats());
			m.put("date",date);
				
		}
				
		ModelAndView mav = new ModelAndView("success",m);
		
		
		return mav;
	}

}
