const express = require('express');
const app = express();
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";
const bodyParser = require("body-parser");
var crypto = require('crypto');
var ObjectId = require('mongodb').ObjectId; 

app.use(bodyParser.urlencoded({
  extended: true
}));
app.use(bodyParser.json());

app.post('/login',(req,res,next)=>{
   var usr = req.body.username;
   var rawpsd = req.body.password;
   var mykey = crypto.createCipher('aes-128-cbc', 'mypassword');
   var cyrpas = mykey.update(rawpsd, 'utf8', 'hex')+ mykey.final('hex');
   MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mydb");
    var query = { username: usr ,password:cyrpas};
    dbo.collection("users").find(query).toArray(function(err, result) {
      if (err) throw err;
      console.log(result);
      if(result.length==0){
         res.send("User Doesnt Exist please register by using /register link");
        }
      else{
          res.send("Success");
          }

      db.close();
    });
  });
});

app.get('/getUser',(req,res,next)=>{
  var idq = req.query.id;
  MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mydb");
    var query = { _id:ObjectId(idq)};
    dbo.collection("users").find(query).toArray(function(err, result) {
      if (err) throw err;
      res.send(result);
    });
  });
});

app.post('/register',(req,res,next)=>{
    var usr = req.body.username;
    var rawpsd = req.body.password;
   var mykey = crypto.createCipher('aes-128-cbc', 'mypassword');
   var cyrpas = mykey.update(rawpsd, 'utf8', 'hex')+ mykey.final('hex');
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("mydb");
        var myobj = { username: usr, password: cyrpas};
        dbo.collection("users").insertOne(myobj, function(err, result) {
          if (err) throw err;
          res.send("User Created Successfully");
          db.close();
        });
      });
   });
app.get('/getAllUsers',(req,res,next)=>{
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("mydb");
        dbo.collection("users").find({}).toArray(function(err, result) {
          if (err) throw err;
          res.send(result);
          db.close();
        });
      });
});

app.put('/updateUser',(req,res,next)=>{
  var idq = req.body.id;
  var usr = req.body.username;
  var rawpsd = req.body.password;
  var mykey = crypto.createCipher('aes-128-cbc', 'mypassword');
  var cyrpas = mykey.update(rawpsd, 'utf8', 'hex')+ mykey.final('hex');;
  MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mydb");
    var query = { "_id":ObjectId(idq)};
    var newvalues = { $set: {username: usr, password: cyrpas } };
    dbo.collection("users").updateOne(query, newvalues, function(err, res) {
      if (err) throw err;
      console.log("1 document updated");
      db.close();
    });
  });
    res.send('Updated User details');
});


app.listen(3000);