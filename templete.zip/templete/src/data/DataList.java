package 
data;

import java.util.HashMap;
import java.util.Map;

public class DataList {
	
	public Map<Integer,Data> dmap = new HashMap<Integer,Data>();
	
	public void addemp(Data data) {
		dmap.put(data.getId(),data);
	}

	public Map<Integer, Data> getDmap() {
		return dmap;
	}

	public void setDmap(Map<Integer, Data> dmap) {
		this.dmap = dmap;
	}
	
}
