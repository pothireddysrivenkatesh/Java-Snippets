package controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;


import data.Data;
import data.DataList;


public class Logic implements Controller {
	
	static DataList dali = new DataList();

	public ModelAndView handleRequest(HttpServletRequest req, HttpServletResponse res) throws Exception {
	
		Data data = new Data();
		data.setName((String)req.getAttribute("name"));
		System.out.println((String)req.getAttribute("name"));
		data.setAge((Integer)req.getAttribute("age"));
		data.setDes((String)req.getAttribute("des"));
		data.setId((Integer)req.getAttribute("id"));
		dali.addemp(data);
		ModelAndView mav = new ModelAndView("addempsuccess",dali.getDmap());
		return mav;
	}

	
}
