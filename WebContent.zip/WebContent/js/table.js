/**
 * 
 */
var emp = [{ "name": "ABC", "age": 12, "add": "Hyderbad", "id": 1011 }, { "name": "BCD", "age": 15, "add": "Pune", "id": 1012 }, { "name": "XYZ", "age": 25, "add": "Kakinada", "id": 1013} ];
var tab = document.getElementById("table");
var text = "<tr><th>ID</th><th>Name</th><th>Age</th><th>Location</th><th>More</th></tr>";
for (var i = 0; i < emp.length; i++) {
    text = text + "<tr>";
    text = text + "<td>";
    text = text + (emp[i].id);
    text = text + "</td>";
    text = text + "<td>";
    text = text + (emp[i].name);
    text = text + "</td>";
    text = text + "<td>";
    text = text + (emp[i].age);
    text = text + "</td>";
    text = text + "<td>";
    text = text + (emp[i].add);
    text = text + "</td>";
    text = text + "<td>";
    text = text + '<a href="" onclick="return fun('+i+')">Know more</a>';
    text = text + "</td>";
    text = text + "</tr>";
}

tab.innerHTML = text;

var details = document.getElementById("details");
var para = "";
function fun(no){
	if (tab.style.display === "none") {
        tab.style.display = "block";
    } else {
        tab.style.display = "none";
    }
	var det = [emp[no].id,emp[no].name,emp[no].age,emp[no].add];
	para = "Name of Employee is :"+det[1]+"<br>";
	para = para + "ID of the Employee is :"+det[0]+"<br>";
	para = para + "Age of the Employee is :"+det[2]+"<br>";
	para = para + "Location :" +det[3]+"<br>";
	details.innerHTML = para;
	return false;
}

