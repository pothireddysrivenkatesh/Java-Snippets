package com.main;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test {

	
	public static void main(String args[]) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Spothireddy\\Desktop\\Training\\Testing\\chromedriver_win32/chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.navigate().to("https://www.google.com");
        driver.findElement(By.xpath("//input[@name='q']")).click();
        driver.findElement(By.xpath("//input[@name='q']")).sendKeys("Testing"); 
        driver.findElement(By.xpath("//input[@name='btnK']")).click();
	}
}
