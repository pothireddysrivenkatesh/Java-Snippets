package com.main;

import java.awt.Robot;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Tours {
	public static void main(String args[]) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Spothireddy\\Desktop\\Training\\Testing\\chromedriver_win32/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.navigate().to("http://newtours.demoaut.com/");
		driver.findElement(By.xpath("//input[@name='userName']")).click();
		driver.findElement(By.xpath("//input[@name='userName']")).sendKeys("readonly");
		driver.findElement(By.xpath("//input[@name='password']")).click();
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("readonly");
		driver.findElement(By.xpath("//input[@name='login']")).click();

		Select passcount = new Select(driver.findElement(By.xpath("//select[@name='passCount']")));
		Random ran = new Random();
		int random_no = ran.nextInt(4);
		passcount.selectByIndex(random_no);
		System.out.println(random_no);
		WebElement we ;
		we.
		
		Thread.sleep(5000);
		driver.quit();
		

	}


}
