package com.poi;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadData {

	public void readData(String filePath,String fileName,String sheetName) throws IOException{

		File file =    new File(filePath+"\\"+fileName);
		FileInputStream inputStream = new FileInputStream(file);
		Workbook wb = new XSSFWorkbook(inputStream);
		Sheet sheet = wb.getSheet(sheetName);
		int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();

		//Create a loop over all the rows of excel file to read it
		for (int i = 0; i < rowCount+1; i++) {
			Row row = sheet.getRow(i);

			//Create a loop to print cell values in a row
			for (int j = 0; j < row.getLastCellNum(); j++) {

				//Print Excel data in console
				System.out.print(row.getCell(j).getStringCellValue()+"|| ");
			}
			System.out.println();
			wb.close();
		}
	}

	
	public static void main(String args[]) throws IOException{

		ReadData objExcelFile = new ReadData();
		//String filePath = System.getProperty("user.dir")+"\\src\\excelExportAndFileIO";
		objExcelFile.readData("C:\\Users\\srive\\eclipse-workspace\\Excel_poi\\src\\com\\poi","test.xlsx","test1");
	}
}