package com.dao;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.beans.Sprint;

public class DAO {
JdbcTemplate template;

public void setTemplate(JdbcTemplate template) {
	this.template = template;
}
public int save(Sprint p){
	String sql="insert into Sprint(Sprint_Code,Sprint_Name,Sprint_Frequency,Project_Code,Sprint_Status) values('"+p.getSprint_Code()+"','"+p.getSprint_Name()+"',"+p.getSprint_Frequency()+",'"+p.getProject_Code()+"',"+p.getSprint_Status()+"";
	return template.update(sql);
}
public int update(Sprint p){
	String sql="update Sprint set Sprint_Name="+p.getSprint_Name()+", Sprint_Frequency='"+p.getSprint_Frequency()+"', Project_Code='"+p.getProject_Code()+"', Sprint_Status="+p.getSprint_Status()+" where Sprint_Code="+p.getSprint_Code()+"";
	return template.update(sql);
}

public List<Sprint> getSprints(){
	return template.query("select * from Sprints",new RowMapper<Sprint>(){
		public Sprint mapRow(ResultSet rs, int row) throws SQLException {
			Sprint e=new Sprint();
			e.setSprint_Code(rs.getString(1));
			e.setSprint_Name(rs.getString(2));
			e.setSprint_Frequency(rs.getInt(3));
			e.setProject_Code(rs.getString(4));
			e.setSprint_Status(rs.getInt(5));
			return e;
		}
	});
}
}
