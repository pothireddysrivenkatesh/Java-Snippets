package com.beans;

public class Sprint{

	private String Sprint_Code;
	private String Sprint_Name;
	private int Sprint_Frequency;
	private String Project_Code;
	private int Sprint_Status;
	
	
	public String getSprint_Code() {
		return Sprint_Code;
	}
	public void setSprint_Code(String sprint_Code) {
		Sprint_Code = sprint_Code;
	}
	public String getSprint_Name() {
		return Sprint_Name;
	}
	public void setSprint_Name(String sprint_Name) {
		Sprint_Name = sprint_Name;
	}
	public int getSprint_Frequency() {
		return Sprint_Frequency;
	}
	public void setSprint_Frequency(int sprint_Frequency) {
		Sprint_Frequency = sprint_Frequency;
	}
	public String getProject_Code() {
		return Project_Code;
	}
	public void setProject_Code(String project_Code) {
		Project_Code = project_Code;
	}
	public int getSprint_Status() {
		return Sprint_Status;
	}
	public void setSprint_Status(int sprint_Status) {
		Sprint_Status = sprint_Status;
	}




}
